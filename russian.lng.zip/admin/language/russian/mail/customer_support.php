<?php
// Text
$_['text_subject']          = 'Тема';
$_['text_greeting']         = 'Благодарим вас. Ответ на ваш вопрос.';
$_['text_enquiry']         	= 'Содержание';
$_['text_category']			= 'Категория';
$_['text_answer']			= 'Ответ';

$_['text_answered']			= 'Ответ на ваш вопрос';

$_['text_lead_url']			= 'Чтобы просмотреть ваш вопрос нажмите на ссылку ниже:';
$_['text_powered_by']       = 'Работает на';
	
?>