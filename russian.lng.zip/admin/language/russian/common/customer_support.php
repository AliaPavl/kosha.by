<?php

// Text
$_['text_customer_support_install']		= 'Поддержка клиентов';
$_['text_customer_support']				= 'Поддержка клиентов';
$_['text_customer_support_category']	= 'Категории';
$_['text_customer_support_requests']	= 'Вопросы и ответы';
?>
