<?php
// Text
 $_['text_footer'] = 'Opencart <a href="http://opencart.com">Opencart</a> &copy; 2009-' . date('Y') . '<br />Version %s';
?>