<?php
// Heading
$_['heading_title']     = 'Покупатели онлайн';

// Text 
$_['text_guest']        = 'Гость';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Покупатель';
$_['column_url']        = 'Последняя просмотренная страница';
$_['column_referer']    = 'Предыдущая просмотренная страница';
$_['column_date_added'] = 'Последний переход';
$_['column_action']     = 'Действие';
?>