<?php
// Text
$_['text_information']    = 'Информация';
$_['text_service']        = 'Поддержка';
$_['text_extra']          = 'Дополнительно';
$_['text_contact']        = 'Служба поддержки';
$_['text_return']         = 'Возврат товара';
$_['text_sitemap']        = 'Карта сайта';
$_['text_manufacturer']   = 'Производители';
$_['text_voucher']        = 'Подарочные сертификаты';
$_['text_affiliate']      = 'Партнерская программа';
$_['text_special']        = 'Наши акции';
$_['text_account']        = 'Личный Кабинет';
$_['text_order']          = 'История заказов';
$_['text_wishlist']       = 'Заметки';
$_['text_newsletter']     = 'Подписка';
$_['text_home']           = 'Главная';
$_['text_wishlist']       = 'Заметки (%s)';
$_['text_compare']        = 'Сравнения (%s)'; 
$_['text_shopping_cart']  = 'Корзина покупок';
$_['text_account']        = 'Личный Кабинет';
$_['text_checkout']       = 'Оформить заказ';
$_['text_powered'] 		  = 'Работает на <a href="http://www.opencart.com">OpenCart</a> %s &copy; %s<br />';
?>