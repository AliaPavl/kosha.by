<?php
// Text
$_['text_title'] = 'ROBOKASSA (WebMoney, Yandex.Money, Money@Mail)';
?>