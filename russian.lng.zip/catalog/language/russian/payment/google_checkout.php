<?php
// Entry
$_['text_title'] = 'Credit Card / Debit Card (Google Checkout)';
?>