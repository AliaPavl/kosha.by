<?php
// Text
$_['text_title'] = 'Pay2Pay (WebMoney, Western Union, Билайн, ВКонтакте, Евросеть и др)';
?>