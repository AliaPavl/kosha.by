<?php
// Text
$_['text_title'] = 'QIWI Кошелек';
$_['sub_text_info'] = '';
$_['sub_text_info_phone'] = 'Номер телефона (последние 10 цифр): ';
?>