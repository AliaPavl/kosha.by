<?php
// Text
$_['text_title'] = 'Webmoney WMU';
?>