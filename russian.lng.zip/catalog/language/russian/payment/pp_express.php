<?php
// Text
$_['text_title'] = 'PayPal Express (включая Кредитные и Дебетовые карты)';
?>