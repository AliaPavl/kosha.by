<?php
// Text
$_['text_voucher']  = 'Подарочный Сертификат (%s)';
?>