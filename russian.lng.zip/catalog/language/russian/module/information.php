<?php
// Heading 
$_['heading_title'] = 'Информация';

// Text
$_['text_contact']  = 'Служба поддержки';
$_['text_sitemap']  = 'Карта сайта';
?>