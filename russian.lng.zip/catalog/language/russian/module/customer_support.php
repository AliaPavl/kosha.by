<?php
// Text
$_['text_customer_support']	= 'Мои вопросы и ответы';
?>
