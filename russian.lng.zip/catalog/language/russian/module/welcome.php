<?php
$_['heading_title'] = 'Добро пожаловать в %s';
?>