<?php
// Heading 
$_['heading_title']  = 'Последние новости';

// Text
$_['text_read_more'] = 'Подробнее';
$_['text_comments']  = 'Комметариев:';
$_['text_headlines'] = 'Все новости / статьи';
?>
