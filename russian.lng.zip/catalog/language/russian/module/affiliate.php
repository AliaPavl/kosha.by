<?php
// Heading 
$_['heading_title']    = 'Партнерский раздел';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Вход';
$_['text_logout']      = 'Выход';
$_['text_forgotten']   = 'Забыли пароль?';
$_['text_account']     = 'Кабинет партнера';
$_['text_edit']        = 'Изменить учетную запись';
$_['text_password']    = 'Изменить пароль';
$_['text_payment']     = 'Способы оплаты';
$_['text_tracking']    = 'Реферальный код';
$_['text_transaction'] = 'Операции';
